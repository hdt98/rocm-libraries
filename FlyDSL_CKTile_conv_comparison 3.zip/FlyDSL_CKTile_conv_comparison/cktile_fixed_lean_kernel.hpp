// Project-local CK Tile fixed-shape lean convolution kernel.
//
// This is a CK Tile-style kernel class (MakeKernelArgs/GridSize/BlockSize/
// IsSupportedArgument/operator()) that can be launched with ck_tile::launch_kernel
// and ck_tile::make_kernel, but internally it uses the lean direct MFMA pipeline
// proven by pure_hip_conv_v3.hip.
//
// Purpose: validate the "new CK Tile small-shape lean pipeline" target without
// first refactoring BlockUniversalGemmAsBsCr. It keeps the CK Tile integration
// surface and host launch conventions, but specializes the transform/pipeline
// for the fixed NHWC/KRSC 3x3 shape used in this bake-off.

#pragma once

#include "ck_tile/core.hpp"
#include "ck_tile/host/kernel_launch.hpp"

namespace ck_tile {

struct FixedLeanConvShape
{
    static constexpr index_t N = 8, Hi = 56, Wi = 56, C = 64;
    static constexpr index_t K = 64, R = 3, S = 3, Ho = 56, Wo = 56;
    static constexpr index_t sH = 1, sW = 1, pH = 1, pW = 1, dH = 1, dW = 1;
    static constexpr index_t M_total = N * Ho * Wo;
    static constexpr index_t N_total = K;
    static constexpr index_t K_total = R * S * C;
    static constexpr index_t Ho_Wo = Ho * Wo;
    static constexpr index_t S_C = S * C;
    static constexpr index_t R_S_C = R * S * C;
};

struct FixedLeanKernelArgs
{
    const half_t* __restrict__ A;
    const half_t* __restrict__ B;
    half_t* __restrict__ D;
    uint32_t A_bytes;
    uint32_t B_bytes;
    uint32_t D_bytes;
};

struct FixedShapeGroupedConvFwdLeanKernel
{
    using Shape = FixedLeanConvShape;

    static constexpr index_t M_TILE = 64;
    static constexpr index_t N_TILE = 64;
    static constexpr index_t K_TILE = 128;
    static constexpr index_t K_PAD  = 136;

    static constexpr index_t M_WARP = 2;
    static constexpr index_t N_WARP = 2;
    static constexpr index_t WARP_SIZE = 64;
    static constexpr index_t BLOCK_SIZE = M_WARP * N_WARP * WARP_SIZE;

    static constexpr index_t MFMA_K = 32;
    static constexpr index_t M_PER_WARP = M_TILE / M_WARP;
    static constexpr index_t N_PER_WARP = N_TILE / N_WARP;
    static constexpr index_t K_STEPS = K_TILE / MFMA_K;

    static constexpr index_t LDG_VEC_A = 4;
    static constexpr index_t LDG_VEC_B = 8;
    static constexpr index_t A_VECS_PER_THREAD = (M_TILE * K_TILE) / (BLOCK_SIZE * LDG_VEC_A);
    static constexpr index_t B_VECS_PER_THREAD = (N_TILE * K_TILE) / (BLOCK_SIZE * LDG_VEC_B);

    static constexpr index_t A_LDS_ELTS = M_TILE * K_PAD;
    static constexpr index_t B_LDS_ELTS = N_TILE * K_PAD;
    static constexpr index_t C_LDS_ELTS = M_TILE * N_TILE;

    static constexpr index_t kBlockSize = BLOCK_SIZE;

    CK_TILE_HOST static const std::string GetName()
    {
        return "fixed_shape_grouped_conv_fwd_lean_m64n64k128";
    }

    CK_TILE_HOST static FixedLeanKernelArgs MakeKernelArgs(const void* in_ptr,
                                                           const void* wei_ptr,
                                                           void* out_ptr)
    {
        return FixedLeanKernelArgs{
            reinterpret_cast<const half_t*>(in_ptr),
            reinterpret_cast<const half_t*>(wei_ptr),
            reinterpret_cast<half_t*>(out_ptr),
            static_cast<uint32_t>(Shape::N * Shape::Hi * Shape::Wi * Shape::C * sizeof(half_t)),
            static_cast<uint32_t>(Shape::K * Shape::R * Shape::S * Shape::C * sizeof(half_t)),
            static_cast<uint32_t>(Shape::N * Shape::Ho * Shape::Wo * Shape::K * sizeof(half_t))};
    }

    CK_TILE_HOST static dim3 GridSize(const FixedLeanKernelArgs&)
    {
        return dim3((Shape::M_total + M_TILE - 1) / M_TILE,
                    (Shape::N_total + N_TILE - 1) / N_TILE,
                    1);
    }

    CK_TILE_HOST_DEVICE static constexpr dim3 BlockSize() { return dim3(BLOCK_SIZE, 1, 1); }

    CK_TILE_HOST static bool IsSupportedArgument(const FixedLeanKernelArgs&) { return true; }

    using float4_t = __attribute__((ext_vector_type(4))) float;
    using fp16x4_t = __attribute__((ext_vector_type(4))) _Float16;
    using fp16x8_t = __attribute__((ext_vector_type(8))) _Float16;
    using i32x2_t = __attribute__((ext_vector_type(2))) int;
    using i32x4_t = __attribute__((ext_vector_type(4))) int;

    CK_TILE_DEVICE static float4_t mfma_f32_16x16x32f16(fp16x8_t a, fp16x8_t b, float4_t c)
    {
        return __builtin_amdgcn_mfma_f32_16x16x32_f16(a, b, c, 0, 0, 0);
    }

    CK_TILE_DEVICE static __amdgpu_buffer_rsrc_t make_rsrc(const void* p, uint32_t bytes)
    {
        return __builtin_amdgcn_make_buffer_rsrc(const_cast<void*>(p), 0, bytes, 0x00027000);
    }

    CK_TILE_DEVICE static fp16x4_t buf_load_b64(__amdgpu_buffer_rsrc_t r, int v_off_b)
    {
        i32x2_t v = __builtin_amdgcn_raw_buffer_load_b64(r, v_off_b, 0, 0);
        fp16x4_t out;
        __builtin_memcpy(&out, &v, 8);
        return out;
    }

    CK_TILE_DEVICE static fp16x8_t buf_load_b128(__amdgpu_buffer_rsrc_t r, int v_off_b)
    {
        i32x4_t v = __builtin_amdgcn_raw_buffer_load_b128(r, v_off_b, 0, 0);
        fp16x8_t out;
        __builtin_memcpy(&out, &v, 16);
        return out;
    }

    CK_TILE_DEVICE static void unpack_m(int m, int& n, int& ho, int& wo)
    {
        n = m / Shape::Ho_Wo;
        int rest = m - n * Shape::Ho_Wo;
        ho = rest / Shape::Wo;
        wo = rest - ho * Shape::Wo;
    }

    CK_TILE_DEVICE static void unpack_k(int k, int& r, int& s, int& c)
    {
        r = k / Shape::S_C;
        int rest = k - r * Shape::S_C;
        s = rest / Shape::C;
        c = rest - s * Shape::C;
    }

    template <int K_TILES_KNOWN, int K_TAIL>
    CK_TILE_DEVICE static void body(const FixedLeanKernelArgs& args,
                                    half_t* A_lds_raw,
                                    half_t* B_lds_raw,
                                    half_t* C_lds_raw)
    {
        _Float16* A_lds = reinterpret_cast<_Float16*>(A_lds_raw);
        _Float16* B_lds = reinterpret_cast<_Float16*>(B_lds_raw);
        _Float16* C_lds = reinterpret_cast<_Float16*>(C_lds_raw);

        const int tid = threadIdx.x;
        const int warp_id = tid / WARP_SIZE;
        const int lane = tid % WARP_SIZE;

        const int m_warp = warp_id / N_WARP;
        const int n_warp = warp_id % N_WARP;

        const int row_in_warp = lane % 16;
        const int col_block = lane / 16;
        const int m_base = m_warp * M_PER_WARP;
        const int n_base = n_warp * N_PER_WARP;

        const int block_m = blockIdx.x * M_TILE;
        const int block_n = blockIdx.y * N_TILE;

        auto A_rsrc = make_rsrc(args.A, args.A_bytes);
        auto B_rsrc = make_rsrc(args.B, args.B_bytes);

        float4_t acc00 = {0, 0, 0, 0};
        float4_t acc01 = {0, 0, 0, 0};
        float4_t acc10 = {0, 0, 0, 0};
        float4_t acc11 = {0, 0, 0, 0};

        #pragma unroll
        for(int kt = 0; kt < K_TILES_KNOWN; ++kt)
        {
            const int q_base = kt * K_TILE;
            const bool is_tail = (kt == K_TILES_KNOWN - 1) && (K_TAIL != K_TILE);
            const int k_lim = is_tail ? K_TAIL : K_TILE;

            int a_offs[A_VECS_PER_THREAD];
            int a_lds_offs[A_VECS_PER_THREAD];

            #pragma unroll
            for(int ai = 0; ai < A_VECS_PER_THREAD; ++ai)
            {
                const int linear = ai * BLOCK_SIZE * LDG_VEC_A + tid * LDG_VEC_A;
                const int a_row = linear / K_TILE;
                const int a_col = linear % K_TILE;
                const int gm = block_m + a_row;
                const int gq = q_base + a_col;

                int n = 0, ho = 0, wo = 0, r = 0, s = 0, c = 0;
                unpack_m(gm, n, ho, wo);
                unpack_k(gq, r, s, c);

                // CK Tile transform-DAG, hand-specialized:
                // merge^-1(M), merge^-1(K), embed(stride/dilation), pad check.
                const int hi = ho * Shape::sH - Shape::pH + r * Shape::dH;
                const int wi = wo * Shape::sW - Shape::pW + s * Shape::dW;
                const bool valid =
                    ((unsigned)hi < (unsigned)Shape::Hi) &
                    ((unsigned)wi < (unsigned)Shape::Wi) &
                    (a_col < k_lim);
                const int real_off_b =
                    (((n * Shape::Hi + hi) * Shape::Wi + wi) * Shape::C + c) *
                    static_cast<int>(sizeof(half_t));
                a_offs[ai] = valid ? real_off_b : static_cast<int>(0x80000000);
                a_lds_offs[ai] = a_row * K_PAD + a_col;
            }

            fp16x4_t a_vec[A_VECS_PER_THREAD];
            #pragma unroll
            for(int ai = 0; ai < A_VECS_PER_THREAD; ++ai)
            {
                a_vec[ai] = buf_load_b64(A_rsrc, a_offs[ai]);
            }

            int b_offs[B_VECS_PER_THREAD];
            int b_lds_offs[B_VECS_PER_THREAD];
            #pragma unroll
            for(int bi = 0; bi < B_VECS_PER_THREAD; ++bi)
            {
                const int linear = bi * BLOCK_SIZE * LDG_VEC_B + tid * LDG_VEC_B;
                const int b_row = linear / K_TILE;
                const int b_col = linear % K_TILE;
                const int gn = block_n + b_row;
                const int gq = q_base + b_col;
                const bool valid = (gn < Shape::N_total) & (b_col < k_lim);
                const int real_off_b =
                    (gn * Shape::R_S_C + gq) * static_cast<int>(sizeof(half_t));
                b_offs[bi] = valid ? real_off_b : static_cast<int>(0x80000000);
                b_lds_offs[bi] = b_row * K_PAD + b_col;
            }

            fp16x8_t b_vec[B_VECS_PER_THREAD];
            #pragma unroll
            for(int bi = 0; bi < B_VECS_PER_THREAD; ++bi)
            {
                b_vec[bi] = buf_load_b128(B_rsrc, b_offs[bi]);
            }

            #pragma unroll
            for(int ai = 0; ai < A_VECS_PER_THREAD; ++ai)
            {
                *reinterpret_cast<fp16x4_t*>(&A_lds[a_lds_offs[ai]]) = a_vec[ai];
            }
            #pragma unroll
            for(int bi = 0; bi < B_VECS_PER_THREAD; ++bi)
            {
                *reinterpret_cast<fp16x8_t*>(&B_lds[b_lds_offs[bi]]) = b_vec[bi];
            }

            block_sync_lds();

            #pragma unroll
            for(int ks = 0; ks < K_STEPS; ++ks)
            {
                const int k_base = ks * 32;
                fp16x8_t a0 = *reinterpret_cast<const fp16x8_t*>(
                    &A_lds[(m_base + row_in_warp) * K_PAD + k_base + col_block * 8]);
                fp16x8_t b0 = *reinterpret_cast<const fp16x8_t*>(
                    &B_lds[(n_base + row_in_warp) * K_PAD + k_base + col_block * 8]);
                fp16x8_t a1 = *reinterpret_cast<const fp16x8_t*>(
                    &A_lds[(m_base + 16 + row_in_warp) * K_PAD + k_base + col_block * 8]);
                fp16x8_t b1 = *reinterpret_cast<const fp16x8_t*>(
                    &B_lds[(n_base + 16 + row_in_warp) * K_PAD + k_base + col_block * 8]);

                acc00 = mfma_f32_16x16x32f16(a0, b0, acc00);
                acc01 = mfma_f32_16x16x32f16(a0, b1, acc01);
                acc10 = mfma_f32_16x16x32f16(a1, b0, acc10);
                acc11 = mfma_f32_16x16x32f16(a1, b1, acc11);
            }

            block_sync_lds();
        }

        auto store_acc = [&](const float4_t& v, int m_off, int n_off) {
            #pragma unroll
            for(int i = 0; i < 4; ++i)
            {
                const int row = m_off + col_block * 4 + i;
                const int col = n_off + row_in_warp;
                C_lds[row * N_TILE + col] = static_cast<_Float16>(v[i]);
            }
        };

        store_acc(acc00, m_base, n_base);
        store_acc(acc01, m_base, n_base + 16);
        store_acc(acc10, m_base + 16, n_base);
        store_acc(acc11, m_base + 16, n_base + 16);
        block_sync_lds();

        constexpr int OUT_VECS_TOTAL = (M_TILE * N_TILE) / 8;
        constexpr int OUT_VECS_PER_THREAD = OUT_VECS_TOTAL / BLOCK_SIZE;
        #pragma unroll
        for(int oi = 0; oi < OUT_VECS_PER_THREAD; ++oi)
        {
            const int vec_id = oi * BLOCK_SIZE + tid;
            const int row = vec_id / (N_TILE / 8);
            const int col = (vec_id % (N_TILE / 8)) * 8;
            const int gm = block_m + row;
            const int gn = block_n + col;
            const bool valid = (gm < Shape::M_total) & ((gn + 8) <= Shape::N_total);
            int n = 0, ho = 0, wo = 0;
            unpack_m(gm, n, ho, wo);
            const index_t base =
                static_cast<index_t>(n) * Shape::Ho * Shape::Wo * Shape::K +
                static_cast<index_t>(ho) * Shape::Wo * Shape::K +
                static_cast<index_t>(wo) * Shape::K + gn;
            const fp16x8_t v =
                *reinterpret_cast<const fp16x8_t*>(&C_lds[row * N_TILE + col]);
            if(valid)
            {
                *reinterpret_cast<fp16x8_t*>(&reinterpret_cast<_Float16*>(args.D)[base]) = v;
            }
        }
    }

    CK_TILE_DEVICE void operator()(FixedLeanKernelArgs args) const
    {
        __shared__ half_t A_lds[A_LDS_ELTS];
        __shared__ half_t B_lds[B_LDS_ELTS];
        __shared__ half_t C_lds[C_LDS_ELTS];
        body<5, 64>(args, A_lds, B_lds, C_lds);
    }
};

} // namespace ck_tile
