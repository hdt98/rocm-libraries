// Copyright 2026 — DSL bake-off harness
// Implicit-GEMM forward convolution shared problem definition.
//
// Layouts:
//   A (input):   NHWC,   fp16,  shape [N, Hi, Wi, C]
//   B (weight):  KRSC,   fp16,  shape [K, R, S, C]
//   D (output):  NHWK,   fp16,  shape [N, Ho, Wo, K]
//
// Hyperparameters: stride, pad, dilation in H/W.

#pragma once
#include <hip/hip_runtime.h>
#include <hip/hip_fp16.h>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <chrono>
#include <vector>
#include <random>
#include <algorithm>
#include <cmath>

#define CK_CHECK_HIP(expr)                                                      \
    do {                                                                        \
        hipError_t _err = (expr);                                               \
        if (_err != hipSuccess) {                                               \
            std::fprintf(stderr, "HIP error %d (%s) at %s:%d\n",                \
                         (int)_err, hipGetErrorString(_err), __FILE__, __LINE__);\
            std::exit(1);                                                       \
        }                                                                       \
    } while (0)

struct ConvProblem {
    // Problem dims
    int N, Hi, Wi, C;
    int K, R, S;
    int sH, sW;
    int pH, pW;
    int dH, dW;
    int Ho, Wo;

    static ConvProblem make_default() {
        ConvProblem p{};
        p.N = 8;  p.Hi = 56; p.Wi = 56; p.C = 64;
        p.K = 64; p.R = 3;   p.S = 3;
        p.sH = 1; p.sW = 1;
        p.pH = 1; p.pW = 1;
        p.dH = 1; p.dW = 1;
        p.compute_out();
        return p;
    }

    void compute_out() {
        Ho = (Hi + 2*pH - dH*(R-1) - 1) / sH + 1;
        Wo = (Wi + 2*pW - dW*(S-1) - 1) / sW + 1;
    }

    // Implicit-GEMM dims
    int M_total() const { return N * Ho * Wo; }
    int N_total() const { return K; }
    int K_total() const { return R * S * C; }

    long long flops() const {
        // 2 * M * N * K
        return 2LL * M_total() * K * (long long)(R * S * C);
    }

    void print(const char* tag) const {
        std::printf(
          "[%s] N=%d Hi=%d Wi=%d C=%d  K=%d R=%d S=%d  s=(%d,%d) p=(%d,%d) d=(%d,%d)  Ho=%d Wo=%d  M=%d N=%d K=%d  flops=%.3f G\n",
          tag, N, Hi, Wi, C, K, R, S, sH, sW, pH, pW, dH, dW, Ho, Wo,
          M_total(), N_total(), K_total(), flops()/1e9);
    }
};

inline size_t in_size(const ConvProblem& p)   { return (size_t)p.N * p.Hi * p.Wi * p.C; }
inline size_t wei_size(const ConvProblem& p)  { return (size_t)p.K * p.R * p.S * p.C; }
inline size_t out_size(const ConvProblem& p)  { return (size_t)p.N * p.Ho * p.Wo * p.K; }

// CPU reference: NHWC × KRSC -> NHWK (fp32 accumulation).
// Slow but correct. Used for verification.
inline void conv_cpu_ref(const ConvProblem& p,
                         const __half* A,
                         const __half* B,
                         __half* D)
{
    int N = p.N, Hi = p.Hi, Wi = p.Wi, C = p.C;
    int K = p.K, R = p.R, S = p.S;
    int Ho = p.Ho, Wo = p.Wo;
    int sH = p.sH, sW = p.sW, pH = p.pH, pW = p.pW, dH = p.dH, dW = p.dW;

    auto idxA = [&](int n, int h, int w, int c) -> size_t {
        return ((size_t)n * Hi + h) * Wi * C + (size_t)w * C + c;
    };
    auto idxB = [&](int k, int r, int s, int c) -> size_t {
        return ((size_t)k * R + r) * S * C + (size_t)s * C + c;
    };
    auto idxD = [&](int n, int h, int w, int k) -> size_t {
        return ((size_t)n * Ho + h) * Wo * K + (size_t)w * K + k;
    };

    #pragma omp parallel for collapse(3)
    for (int n = 0; n < N; ++n) {
      for (int ho = 0; ho < Ho; ++ho) {
        for (int wo = 0; wo < Wo; ++wo) {
          for (int k = 0; k < K; ++k) {
            float acc = 0.f;
            for (int r = 0; r < R; ++r) {
              int hi = ho * sH - pH + r * dH;
              if (hi < 0 || hi >= Hi) continue;
              for (int s = 0; s < S; ++s) {
                int wi = wo * sW - pW + s * dW;
                if (wi < 0 || wi >= Wi) continue;
                for (int c = 0; c < C; ++c) {
                  float a = __half2float(A[idxA(n, hi, wi, c)]);
                  float b = __half2float(B[idxB(k, r, s, c)]);
                  acc += a * b;
                }
              }
            }
            D[idxD(n, ho, wo, k)] = __float2half(acc);
          }
        }
      }
    }
}

// Compare GPU output vs reference. Returns max absolute / relative error.
struct Diff {
    double max_abs, max_rel, mean_abs;
    int    bad_count;
    int    total;
};

inline Diff compare_outputs(const __half* a, const __half* b, size_t n,
                            float atol = 1e-2f, float rtol = 5e-2f)
{
    Diff d{0,0,0,0,(int)n};
    double sum_abs = 0;
    for (size_t i = 0; i < n; ++i) {
        float fa = __half2float(a[i]);
        float fb = __half2float(b[i]);
        double da = std::fabs(fa - fb);
        double dr = da / std::max(1e-6, (double)std::fabs(fb));
        sum_abs += da;
        if (da > d.max_abs) d.max_abs = da;
        if (dr > d.max_rel) d.max_rel = dr;
        if (da > atol && dr > rtol) d.bad_count++;
    }
    d.mean_abs = sum_abs / n;
    return d;
}

// Fill helpers (deterministic).
inline void fill_random(std::vector<__half>& v, uint32_t seed, float scale = 0.02f)
{
    std::mt19937 rng(seed);
    std::uniform_real_distribution<float> u(-1.f, 1.f);
    for (auto& x : v) x = __float2half(u(rng) * scale);
}

// Simple, accurate GPU-side timing (HIP events).
struct GpuTimer {
    hipEvent_t s, e;
    GpuTimer()  { CK_CHECK_HIP(hipEventCreate(&s)); CK_CHECK_HIP(hipEventCreate(&e)); }
    ~GpuTimer() { hipEventDestroy(s); hipEventDestroy(e); }
    void start(hipStream_t st = 0) { CK_CHECK_HIP(hipEventRecord(s, st)); }
    float stop(hipStream_t st = 0) {
        CK_CHECK_HIP(hipEventRecord(e, st));
        CK_CHECK_HIP(hipEventSynchronize(e));
        float ms = 0;
        CK_CHECK_HIP(hipEventElapsedTime(&ms, s, e));
        return ms;
    }
};
