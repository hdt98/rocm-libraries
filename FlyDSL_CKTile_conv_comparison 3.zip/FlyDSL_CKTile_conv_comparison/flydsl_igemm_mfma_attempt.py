#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
#
# FlyDSL fused implicit-GEMM convolution attempt.
#
# This is the no-shortcuts version: no im2col buffer.  The A tile is loaded by
# manually applying the convolution inverse map:
#
#   GEMM A[m, q] -> input[n, hi, wi, c]
#   m = n*Ho*Wo + ho*Wo + wo
#   q = r*S*C + s*C + c
#   hi = ho*stride_h - pad_h + r*dilation_h
#   wi = wo*stride_w - pad_w + s*dilation_w
#
# Then A and B are staged through LDS and consumed by gfx950
# mfma_f32_16x16x32_f16. This is the direct FlyDSL analogue of the hand-HIP v2
# kernel, except written through FlyDSL ops.

from __future__ import annotations

import torch
import torch.nn.functional as F

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import arith, buffer_ops, gpu, rocdl, vector, range_constexpr
from flydsl.expr.typing import T
from flydsl.utils.smem_allocator import SmemAllocator, SmemPtr
from flydsl.compiler.kernel_function import CompilationContext
from flydsl._mlir import ir


N = 8
HI = 56
WI = 56
C = 64
K = 64
R = 3
S = 3
SH = 1
SW = 1
PH = 1
PW = 1
DH = 1
DW = 1
HO = 56
WO = 56

M_TOTAL = N * HO * WO
N_TOTAL = K
K_TOTAL = R * S * C
OUT_TOTAL = M_TOTAL * N_TOTAL
FLOPS = 2 * M_TOTAL * N_TOTAL * K_TOTAL

# Tuned fused IGEMM tile attempt. This mirrors the CK Tile winning
# neighborhood: 64x64 output tile, 4 waves as a 2x2 warp layout.
BLOCK_M = 64
BLOCK_N = 64
BLOCK_K = 128
K_PAD = 136
THREADS = 256
WARP = 64

MFMA_M = 16
MFMA_N = 16
MFMA_K = 32
K_STEPS = BLOCK_K // MFMA_K

LDG_VEC_A = 4  # 4xf16 = 64 bits
LDG_VEC_B = 8  # 8xf16 = 128 bits

WAVES_M = 2
WAVES_N = 2
M_PER_WARP = BLOCK_M // WAVES_M
N_PER_WARP = BLOCK_N // WAVES_N

A_LDS_ELEMS = BLOCK_M * K_PAD
B_LDS_ELEMS = BLOCK_N * K_PAD
C_LDS_ELEMS = BLOCK_M * BLOCK_N

allocator = SmemAllocator(None, arch="gfx950", global_sym_name="fly_igemm_smem")
lds_offset = allocator._align(allocator.ptr, 16)
allocator.ptr = lds_offset + (A_LDS_ELEMS + B_LDS_ELEMS + C_LDS_ELEMS) * 2


@flyc.kernel
def igemm_conv2d_kernel(A: fx.Tensor, B: fx.Tensor, D: fx.Tensor):
    base_ptr = allocator.get_base()
    lds = SmemPtr(
        base_ptr,
        lds_offset,
        T.f16,
        shape=(A_LDS_ELEMS + B_LDS_ELEMS + C_LDS_ELEMS,),
    )
    lds_mem = lds.get()

    A_s = SmemPtr(base_ptr, lds_offset, T.f16, shape=(A_LDS_ELEMS,)).get()
    B_s = SmemPtr(base_ptr, lds_offset + A_LDS_ELEMS * 2, T.f16, shape=(B_LDS_ELEMS,)).get()
    C_s = SmemPtr(
        base_ptr,
        lds_offset + (A_LDS_ELEMS + B_LDS_ELEMS) * 2,
        T.f16,
        shape=(C_LDS_ELEMS,),
    ).get()

    tid = fx.Int32(gpu.thread_id("x"))
    bid = fx.Int32(gpu.block_id("x"))
    lane = tid % WARP
    warp_id = tid // WARP

    block_m = bid * BLOCK_M
    block_n = fx.Int32(0)  # N_TOTAL == 64, one N tile

    a_rsrc = buffer_ops.create_buffer_resource(A, max_size=True)
    b_rsrc = buffer_ops.create_buffer_resource(B, max_size=True)
    d_rsrc = buffer_ops.create_buffer_resource(D, max_size=True)

    zero_v4_f16 = arith.constant_vector(0.0, T.vec(4, T.f16))
    zero_v8_f16 = arith.constant_vector(0.0, T.vec(8, T.f16))
    zero_acc = arith.constant_vector(0.0, T.vec(4, T.f32))

    # ------------------------------------------------------------
    # MFMA compute. Four warps are arranged 2x2; each warp computes 32x32
    # using four 16x16 MFMA accumulators.
    # Lane mapping follows gfx950 mfma_f32_16x16x32_f16.
    # ------------------------------------------------------------
    row_in_warp = lane % 16
    col_block = lane // 16
    warp_m = warp_id // WAVES_N
    warp_n = warp_id - warp_m * WAVES_N
    m_base = warp_m * M_PER_WARP
    n_base = warp_n * N_PER_WARP

    acc00 = zero_acc
    acc01 = zero_acc
    acc10 = zero_acc
    acc11 = zero_acc
    for kt in range_constexpr((K_TOTAL + BLOCK_K - 1) // BLOCK_K):
        q_base = kt * BLOCK_K

        # ------------------------------------------------------------
        # Load A tile: BLOCK_M x BLOCK_K.
        # 64*64 elements, 4xf16 per vector, 4 vectors/thread.
        # ------------------------------------------------------------
        for ai in range_constexpr((BLOCK_M * BLOCK_K) // (THREADS * LDG_VEC_A)):
            a_linear = tid * LDG_VEC_A + ai * THREADS * LDG_VEC_A
            a_row = a_linear // BLOCK_K
            a_col = a_linear % BLOCK_K
            gm = block_m + a_row
            gq = q_base + a_col

            n = gm // (HO * WO)
            m_rem = gm - n * (HO * WO)
            ho = m_rem // WO
            wo = m_rem - ho * WO

            r0 = gq // (S * C)
            q_rem = gq - r0 * (S * C)
            s0 = q_rem // C
            c0 = q_rem - s0 * C

            hi = ho * SH - PH + r0 * DH
            wi = wo * SW - PW + s0 * DW
            valid_a = (gm < M_TOTAL) & (gq < K_TOTAL) & (hi >= 0) & (hi < HI) & (
                wi >= 0
            ) & (wi < WI) & ((c0 + LDG_VEC_A) <= C)
            a_off_raw = ((n * HI + hi) * WI + wi) * C + c0
            a_off = valid_a.select(fx.Int32(a_off_raw), fx.Int32(0))
            a_i32x2 = buffer_ops.buffer_load(a_rsrc, a_off // 2, vec_width=2, dtype=T.i32)
            a_vec = vector.bitcast(T.vec(4, T.f16), a_i32x2)
            a_vec = arith.select(valid_a, a_vec, zero_v4_f16)
            vector.store(a_vec, A_s, [fx.Index(a_row * K_PAD + a_col)], alignment=8)

        # ------------------------------------------------------------
        # Load B tile: BLOCK_N x BLOCK_K, B is KRSC flattened as [K, q].
        # ------------------------------------------------------------
        for bi in range_constexpr((BLOCK_N * BLOCK_K) // (THREADS * LDG_VEC_B)):
            b_linear = tid * LDG_VEC_B + bi * THREADS * LDG_VEC_B
            b_row = b_linear // BLOCK_K
            b_col = b_linear % BLOCK_K
            gn = block_n + b_row
            gq_b = q_base + b_col
            valid_b = (gn < N_TOTAL) & ((gq_b + LDG_VEC_B) <= K_TOTAL)
            b_off_raw = gn * K_TOTAL + gq_b
            b_off = valid_b.select(fx.Int32(b_off_raw), fx.Int32(0))
            b_i32x4 = buffer_ops.buffer_load(b_rsrc, b_off // 2, vec_width=4, dtype=T.i32)
            b_vec = vector.bitcast(T.vec(8, T.f16), b_i32x4)
            b_vec = arith.select(valid_b, b_vec, zero_v8_f16)
            vector.store(b_vec, B_s, [fx.Index(b_row * K_PAD + b_col)], alignment=16)

        gpu.barrier()

        for ks in range_constexpr(K_STEPS):
            k_base = ks * MFMA_K
            a0 = vector.load_op(
                T.vec(8, T.f16),
                A_s,
                [fx.Index((m_base + row_in_warp) * K_PAD + k_base + col_block * 8)],
            )
            a1 = vector.load_op(
                T.vec(8, T.f16),
                A_s,
                [fx.Index((m_base + 16 + row_in_warp) * K_PAD + k_base + col_block * 8)],
            )
            b0 = vector.load_op(
                T.vec(8, T.f16),
                B_s,
                [fx.Index((n_base + row_in_warp) * K_PAD + k_base + col_block * 8)],
            )
            b1 = vector.load_op(
                T.vec(8, T.f16),
                B_s,
                [fx.Index((n_base + 16 + row_in_warp) * K_PAD + k_base + col_block * 8)],
            )
            acc00 = rocdl.mfma_f32_16x16x32_f16(T.vec(4, T.f32), [a0, b0, acc00, 0, 0, 0])
            acc01 = rocdl.mfma_f32_16x16x32_f16(T.vec(4, T.f32), [a0, b1, acc01, 0, 0, 0])
            acc10 = rocdl.mfma_f32_16x16x32_f16(T.vec(4, T.f32), [a1, b0, acc10, 0, 0, 0])
            acc11 = rocdl.mfma_f32_16x16x32_f16(T.vec(4, T.f32), [a1, b1, acc11, 0, 0, 0])

        gpu.barrier()

    # ------------------------------------------------------------
    # Store via an LDS C-shuffle so global stores are contiguous in K.
    # ------------------------------------------------------------
    def store_acc_tile(acc_vec, m_off, n_off):
        for si in range_constexpr(4):
            row = m_off + col_block * 4 + si
            col = n_off + row_in_warp
            val = vector.extract(acc_vec, static_position=[si], dynamic_position=[])
            val_h = fx.Float32(val).to(fx.Float16).ir_value()
            vec1 = vector.from_elements(T.vec(1, T.f16), [val_h])
            vector.store(vec1, C_s, [fx.Index(row * BLOCK_N + col)], alignment=2)

    store_acc_tile(acc00, m_base, n_base)
    store_acc_tile(acc01, m_base, n_base + 16)
    store_acc_tile(acc10, m_base + 16, n_base)
    store_acc_tile(acc11, m_base + 16, n_base + 16)

    gpu.barrier()

    # 512 vec8 stores per block; 2 per thread.
    for so in range_constexpr((BLOCK_M * BLOCK_N) // (THREADS * 8)):
        vec_id = tid + so * THREADS
        store_row = vec_id // 8
        store_col = (vec_id % 8) * 8
        out_m = block_m + store_row
        out_n = store_col
        valid_out = out_m < M_TOTAL
        out_off_raw = out_m * N_TOTAL + out_n
        out_off = valid_out.select(fx.Int32(out_off_raw), fx.Int32(0))
        out_vec = vector.load_op(T.vec(8, T.f16), C_s, [fx.Index(store_row * BLOCK_N + store_col)])
        buffer_ops.buffer_store(out_vec, d_rsrc, out_off, offset_is_bytes=False)


@flyc.jit
def launch_igemm(A: fx.Tensor, B: fx.Tensor, D: fx.Tensor, stream: fx.Stream):
    allocator.finalized = False
    ctx = CompilationContext.get_current()
    with ir.InsertionPoint(ctx.gpu_module_body):
        allocator.finalize()

    grid = (M_TOTAL // BLOCK_M, 1, 1)
    igemm_conv2d_kernel(A, B, D).launch(grid=grid, block=(THREADS, 1, 1), stream=stream)


def ref_torch(a, b):
    x = a.permute(0, 3, 1, 2).contiguous()
    w = b.permute(0, 3, 1, 2).contiguous()
    y = F.conv2d(x, w, padding=(PH, PW), stride=(SH, SW), dilation=(DH, DW))
    return y.permute(0, 2, 3, 1).contiguous()


def bench_ms(fn, stream, warmup=10, iters=100):
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    start.record(stream)
    for _ in range(iters):
        fn()
    end.record(stream)
    torch.cuda.synchronize()
    return start.elapsed_time(end) / iters


def bench_graph_ms(launch_into_stream, stream, iters_per_replay=200, replays=5, warmup=3):
    # Warmup the JIT cache and the launch path on the chosen stream.
    for _ in range(5):
        launch_into_stream(stream)
    torch.cuda.synchronize()

    graph = torch.cuda.CUDAGraph()
    capture_stream = torch.cuda.Stream()
    capture_stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(capture_stream):
        with torch.cuda.graph(graph, stream=capture_stream):
            for _ in range(iters_per_replay):
                launch_into_stream(capture_stream)
    torch.cuda.synchronize()

    for _ in range(warmup):
        graph.replay()
    torch.cuda.synchronize()

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    start.record()
    for _ in range(replays):
        graph.replay()
    end.record()
    torch.cuda.synchronize()
    return start.elapsed_time(end) / (replays * iters_per_replay)


def main():
    print(
        f"[flydsl-igemm-mfma] N={N} H={HI} W={WI} C={C} K={K} R={R} S={S} "
        f"M={M_TOTAL} Ngemm={N_TOTAL} Kgemm={K_TOTAL} flops={FLOPS/1e9:.3f}G"
    )
    torch.manual_seed(1234)
    A = (torch.rand((N, HI, WI, C), device="cuda", dtype=torch.float16) * 0.04 - 0.02).contiguous()
    B = (torch.rand((K, R, S, C), device="cuda", dtype=torch.float16) * 0.04 - 0.02).contiguous()
    D = torch.empty((N, HO, WO, K), device="cuda", dtype=torch.float16)
    ref = ref_torch(A, B)

    stream = torch.cuda.Stream()
    launch_igemm(A, B, D, stream=stream)
    torch.cuda.synchronize()

    diff = (D - ref).abs()
    print(
        f"[flydsl-igemm-mfma] verify: max_abs={diff.max().item():.6f} "
        f"mean_abs={diff.mean().item():.8f} bad_abs_gt_1e-2={(diff > 1e-2).sum().item()}/{D.numel()}"
    )
    if (diff > 1e-2).any():
        return 1

    ms = bench_ms(lambda: launch_igemm(A, B, D, stream=stream), stream, warmup=10, iters=100)
    tflops = FLOPS / (ms * 1e-3) / 1e12
    print(f"[per-launch  ] 100 iters: {ms:.4f} ms / iter, {tflops:.3f} TFLOPS")

    def into(s):
        launch_igemm(A, B, D, stream=s)

    for ipr, rps in [(1, 1000), (10, 200), (200, 5)]:
        gm = bench_graph_ms(into, stream, iters_per_replay=ipr, replays=rps, warmup=3)
        gtflops = FLOPS / (gm * 1e-3) / 1e12
        # Re-verify after graph runs to make sure we're actually computing.
        torch.cuda.synchronize()
        diff_after = (D - ref).abs()
        bad_after = (diff_after > 1e-2).sum().item()
        max_after = diff_after.max().item()
        print(
            f"[cuda-graph  ] {rps} replays x {ipr:>3} iters: {gm:.4f} ms / iter, "
            f"{gtflops:.3f} TFLOPS  bad_after={bad_after} max_after={max_after:.6f}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
