#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
#
# FlyDSL attempt for the same non-bijective operation used in the HIP/CK Tile
# bake-off:
#
#   NHWC fp16 input  [N, H, W, C]
#   KRSC fp16 weight [K, R, S, C]
#   NHWK fp16 output [N, Ho, Wo, K]
#
# This first kernel is intentionally correctness-first. It is not expected to
# compete with CK Tile: each output element is one thread and the non-bijective
# implicit-GEMM mapping is hand-written in scalar arithmetic.
#
# The point is to establish a working FlyDSL baseline and expose where a
# CuTe-style layout DSL currently stops helping: there is no equivalent of
# CK Tile's pad/embed/merge transform DAG for (m,k)->(n,hi,wi,c), so the
# transform becomes manual integer code inside the kernel.

from __future__ import annotations

import os
import sys
import time

import torch
import torch.nn.functional as F

import flydsl.compiler as flyc
import flydsl.expr as fx
from flydsl.expr import buffer_ops, gpu, range_constexpr


# Same shape as conv_problem.hpp.
N = 8
HI = 56
WI = 56
C = 64
K = 64
R = 3
S = 3
SH = 1
SW = 1
PH = 1
PW = 1
DH = 1
DW = 1
HO = (HI + 2 * PH - DH * (R - 1) - 1) // SH + 1
WO = (WI + 2 * PW - DW * (S - 1) - 1) // SW + 1

M_TOTAL = N * HO * WO
OUT_TOTAL = M_TOTAL * K
GEMM_K = R * S * C
FLOPS = 2 * OUT_TOTAL * GEMM_K

THREADS = 256


@flyc.kernel
def conv2d_nhwc_krsc_scalar_kernel(A: fx.Tensor, B: fx.Tensor, D: fx.Tensor):
    tid = gpu.thread_id("x")
    bid = gpu.block_id("x")
    out_idx = bid * THREADS + tid

    a_rsrc = buffer_ops.create_buffer_resource(A, max_size=True)
    b_rsrc = buffer_ops.create_buffer_resource(B, max_size=True)
    d_rsrc = buffer_ops.create_buffer_resource(D, max_size=True)

    zero = fx.Float32(0.0)
    acc = zero

    # Decompose flat output:
    #   out_idx = (((n * Ho + ho) * Wo + wo) * K + k)
    k_out = out_idx % K
    m = out_idx // K
    wo = m % WO
    n_ho = m // WO
    ho = n_ho % HO
    n = n_ho // HO

    in_output = out_idx < OUT_TOTAL

    # This is the non-bijective part. For each output point and each filter
    # coordinate, map back into the input image. Adjacent output points map to
    # overlapping input pixels, so this is not a simple layout stride map.
    for r in range_constexpr(R):
        hi = ho * SH - PH + r * DH
        hi_ok = (hi >= 0) & (hi < HI)
        for s in range_constexpr(S):
            wi = wo * SW - PW + s * DW
            wi_ok = (wi >= 0) & (wi < WI)
            valid_hw = in_output & hi_ok & wi_ok

            for c in range_constexpr(C):
                a_off_raw = ((n * HI + hi) * WI + wi) * C + c
                b_off_raw = ((k_out * R + r) * S + s) * C + c

                # Do not use buffer_load(mask=...) here: with max-size buffer
                # descriptors that path can still turn into an illegal raw
                # pointer access. Select an always-valid offset, then zero the
                # loaded value in SSA.
                a_off = valid_hw.select(fx.Int32(a_off_raw), fx.Int32(0))
                b_off = in_output.select(fx.Int32(b_off_raw), fx.Int32(0))

                a_h = buffer_ops.buffer_load(a_rsrc, a_off, vec_width=1, dtype=fx.Float16)
                b_h = buffer_ops.buffer_load(b_rsrc, b_off, vec_width=1, dtype=fx.Float16)
                a_f_loaded = fx.Float16(a_h).to(fx.Float32)
                a_f = valid_hw.select(a_f_loaded, zero)
                b_f = fx.Float16(b_h).to(fx.Float32)
                acc = acc + (a_f * b_f)

    out_h = acc.to(fx.Float16)
    out_off = in_output.select(fx.Int32(out_idx), fx.Int32(0))
    if in_output:
        buffer_ops.buffer_store(out_h, d_rsrc, out_off)


@flyc.jit
def launch_scalar_conv(A: fx.Tensor, B: fx.Tensor, D: fx.Tensor, stream: fx.Stream):
    grid = ((OUT_TOTAL + THREADS - 1) // THREADS, 1, 1)
    conv2d_nhwc_krsc_scalar_kernel(A, B, D).launch(
        grid=grid, block=(THREADS, 1, 1), stream=stream
    )


def reference_torch(a_nhwc: torch.Tensor, b_krsc: torch.Tensor) -> torch.Tensor:
    # Torch conv2d wants NCHW and KCRS.
    x = a_nhwc.permute(0, 3, 1, 2).contiguous()
    w = b_krsc.permute(0, 3, 1, 2).contiguous()
    y = F.conv2d(x, w, bias=None, stride=(SH, SW), padding=(PH, PW), dilation=(DH, DW))
    return y.permute(0, 2, 3, 1).contiguous()


def bench_ms(fn, stream, warmup=10, iters=50) -> float:
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)
    start.record(stream)
    for _ in range(iters):
        fn()
    end.record(stream)
    torch.cuda.synchronize()
    return start.elapsed_time(end) / iters


def main() -> int:
    print(
        f"[flydsl-scalar] N={N} H={HI} W={WI} C={C} K={K} R={R} S={S} "
        f"Ho={HO} Wo={WO} OUT={OUT_TOTAL} GEMM_K={GEMM_K} flops={FLOPS/1e9:.3f}G"
    )
    print(f"[flydsl-scalar] torch={torch.__version__} hip={torch.version.hip}")
    print(f"[flydsl-scalar] device={torch.cuda.get_device_name(0)}")

    torch.manual_seed(1234)
    # Keep values small to match the half-output tolerance used in the C++ harness.
    A = (torch.rand((N, HI, WI, C), device="cuda", dtype=torch.float16) * 0.04 - 0.02).contiguous()
    B = (torch.rand((K, R, S, C), device="cuda", dtype=torch.float16) * 0.04 - 0.02).contiguous()
    D = torch.empty((N, HO, WO, K), device="cuda", dtype=torch.float16)

    print("[flydsl-scalar] computing torch reference...")
    ref = reference_torch(A, B)

    stream = torch.cuda.Stream()
    # Trigger JIT compile.
    launch_scalar_conv(A, B, D, stream=stream)
    torch.cuda.synchronize()

    max_abs = (D - ref).abs().max().item()
    mean_abs = (D - ref).abs().mean().item()
    bad = ((D - ref).abs() > 1e-2).sum().item()
    print(
        f"[flydsl-scalar] verify: max_abs={max_abs:.6f} "
        f"mean_abs={mean_abs:.8f} bad_abs_gt_1e-2={bad}/{D.numel()}"
    )
    if bad:
        print("[flydsl-scalar] FAILED")
        return 1

    ms = bench_ms(lambda: launch_scalar_conv(A, B, D, stream=stream), stream, warmup=5, iters=20)
    tflops = FLOPS / (ms * 1e-3) / 1e12
    print(f"[flydsl-scalar] 20 iters: {ms:.4f} ms / iter, {tflops:.3f} TFLOPS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
